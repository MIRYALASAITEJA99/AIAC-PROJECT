# SwiftPath — Emergency Corridor System

A real-time web app that connects ambulance drivers, traffic police, and hospital ER teams to clear corridors and save lives.

---

## How to run in VS Code

1. **Open the folder** in VS Code:
   - File → Open Folder → select the `swiftpath` folder

2. **Install the Live Server extension** (if you haven't already):
   - Press `Ctrl+Shift+X` (Extensions panel)
   - Search for **Live Server** by Ritwick Dey → Install

3. **Start the app**:
   - Right-click `pages/login.html` → **Open with Live Server**
   - OR click **Go Live** in the bottom-right status bar

4. The app will open in your browser at `http://127.0.0.1:5500/pages/login.html`

---

## Project structure

```
swiftpath/
├── index.html          ← Main app (driver / police / hospital panels)
├── pages/
│   ├── login.html      ← Login page
│   └── register.html   ← Registration page
├── css/
│   ├── style.css       ← Main app styles
│   └── auth.css        ← Login & register styles
├── js/
│   ├── app.js          ← Main app logic & simulation
│   └── auth.js         ← Login, register, session logic
└── README.md
```

---

## Demo accounts

| Role     | Email                    | Password     |
|----------|--------------------------|--------------|
| Driver   | driver@swiftpath.in      | driver123    |
| Police   | police@swiftpath.in      | police123    |
| Hospital | hospital@swiftpath.in    | hospital123  |

---

## How to use

### As Ambulance Driver
1. Login with driver credentials
2. Select destination hospital
3. Select patient condition (Critical / Serious / Stable)
4. Enter patient details (optional)
5. Click **Dispatch Emergency Alert**
6. The live simulation auto-runs — watch checkpoints update

### As Traffic Police
1. Login with police credentials
2. When a driver dispatches a trip, the alert appears automatically
3. See your assigned checkpoints and ETAs
4. Click **Clear now** on each checkpoint as the ambulance approaches

### As Hospital ER
1. Login with hospital credentials
2. When a trip is dispatched, an incoming patient alert appears
3. See patient condition, ETA, and assigned bay
4. Tick off the ER prep checklist items

> **Note:** All three roles can be open in separate browser tabs simultaneously to see the full simulation in real time. User accounts are stored in browser localStorage.

---

## Features

- Role-based login & registration with session management
- Password strength indicator
- Demo accounts pre-seeded
- Live GPS ambulance simulation with canvas maps
- 4 traffic checkpoints with police action buttons
- Condition-specific ER prep checklists
- Real-time activity log across all panels
- Responsive mobile-first design
- Works fully offline (no server needed)
