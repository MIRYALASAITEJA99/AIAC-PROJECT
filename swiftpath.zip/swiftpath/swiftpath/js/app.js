// ===================== STATE =====================
var state = {
  tripActive: false,
  selectedHospital: null,
  selectedCondition: null,
  patientName: '',
  patientAge: '',
  patientNotes: '',
  progress: 0,
  simTimer: null,
  checkpoints: [
    { id: 1, name: 'Anna Salai Junction', zone: 'Officer A — Zone 1', eta: 2, status: 'pending' },
    { id: 2, name: 'Nandanam Signal', zone: 'Officer B — Zone 2', eta: 4, status: 'pending' },
    { id: 3, name: 'Gemini Flyover', zone: 'Officer C — Zone 3', eta: 7, status: 'pending' },
    { id: 4, name: 'Greams Road Entry', zone: 'Officer D — Zone 4', eta: 9, status: 'pending' },
  ]
};

var checklistItems = {
  Critical: [
    'Defibrillator on standby',
    'Crash cart ready at bay',
    'Cardiologist notified',
    'IV lines prepared',
    'Blood bank alerted (O negative)',
    'X-ray & ECG room cleared',
  ],
  Serious: [
    'Orthopaedic team alerted',
    'Pain management prepared',
    'X-ray room on standby',
    'IV lines and splints ready',
  ],
  Stable: [
    'Standard bay prepared',
    'First aid supplies stocked',
    'Nurse assigned to bay',
  ]
};

var simEvents = [
  { pct: 8,  msg: 'Trip started — police & hospital alerted', type: 'danger' },
  { pct: 18, msg: 'Ambulance moving — GPS tracking active', type: 'info' },
  { pct: 28, msg: 'Checkpoint 1: Anna Salai — police clearing', type: 'warning' },
  { pct: 38, msg: 'Checkpoint 1 cleared — ambulance through', type: 'success' },
  { pct: 48, msg: 'Speed 62 km/h — corridor clear ahead', type: 'info' },
  { pct: 56, msg: 'Checkpoint 2: Nandanam — holding all traffic', type: 'warning' },
  { pct: 64, msg: 'Checkpoint 2 cleared successfully', type: 'success' },
  { pct: 72, msg: 'Hospital ER bay 2 prepared and ready', type: 'info' },
  { pct: 80, msg: 'Checkpoint 3: Gemini Flyover — cleared', type: 'success' },
  { pct: 88, msg: 'Checkpoint 4: Greams Rd — final clearance', type: 'warning' },
  { pct: 96, msg: 'Checkpoint 4 cleared — hospital in sight', type: 'success' },
  { pct: 100, msg: 'Ambulance arrived — patient handed to ER team', type: 'danger' },
];
var firedEvents = [];

// ===================== NAV =====================
function enterApp(role) {
  document.getElementById('splash').classList.add('hidden');
  document.getElementById(role + '-app').classList.remove('hidden');
}

function goBack() {
  ['driver-app','police-app','hospital-app'].forEach(function(id) {
    document.getElementById(id).classList.add('hidden');
  });
  document.getElementById('splash').classList.remove('hidden');
}

// ===================== DRIVER =====================
function selectHospital(el) {
  document.querySelectorAll('.hospital-card').forEach(function(c) { c.classList.remove('selected'); });
  el.classList.add('selected');
  state.selectedHospital = {
    id: el.dataset.id,
    name: el.dataset.name,
    address: el.dataset.address,
    dist: parseFloat(el.dataset.dist),
    beds: parseInt(el.dataset.beds),
    time: parseInt(el.dataset.time),
  };
  checkDispatchReady();
}

function selectCondition(el) {
  document.querySelectorAll('.cond-card').forEach(function(c) { c.classList.remove('selected'); });
  el.classList.add('selected');
  state.selectedCondition = el.dataset.cond;
  checkDispatchReady();
}

function checkDispatchReady() {
  var btn = document.getElementById('dispatch-btn');
  btn.disabled = !(state.selectedHospital && state.selectedCondition);
}

function startTrip() {
  if (!state.selectedHospital || !state.selectedCondition) return;
  state.tripActive = true;
  state.progress = 0;
  state.patientName = document.getElementById('patient-name').value || 'Unknown';
  state.patientAge = document.getElementById('patient-age').value || '--';
  firedEvents = [];

  // Reset checkpoints
  state.checkpoints.forEach(function(cp) { cp.status = 'pending'; });

  // Show active trip UI
  document.getElementById('driver-pretrip').classList.add('hidden');
  document.getElementById('driver-active').classList.remove('hidden');
  document.getElementById('driver-status-text').textContent = 'Trip active — live';
  document.getElementById('driver-live-badge').style.display = 'flex';

  // Fill data
  document.getElementById('trip-hosp-name').textContent = state.selectedHospital.name;
  document.getElementById('trip-hosp-addr').textContent = state.selectedHospital.address;
  document.getElementById('trip-eta').textContent = state.selectedHospital.time;
  document.getElementById('trip-dist').textContent = state.selectedHospital.dist.toFixed(1);

  // Render checkpoints
  renderDriverCheckpoints();

  // Update police & hospital panels
  syncPolicePanel();
  syncHospitalPanel();

  // Draw maps
  drawMap('map-canvas');
  drawMap('police-map-canvas');
  drawMap('hosp-map-canvas');

  // Add first log
  addLog('driver-log', 'Trip started — all units alerted', 'danger');

  // Start simulation
  startSim();
}

function endTrip() {
  state.tripActive = false;
  if (state.simTimer) clearInterval(state.simTimer);

  document.getElementById('driver-active').classList.add('hidden');
  document.getElementById('driver-pretrip').classList.remove('hidden');
  document.getElementById('driver-status-text').textContent = 'Ready to dispatch';
  document.getElementById('driver-live-badge').style.display = 'none';
  document.getElementById('driver-log').innerHTML = '';

  // Clear selections
  document.querySelectorAll('.hospital-card').forEach(function(c) { c.classList.remove('selected'); });
  document.querySelectorAll('.cond-card').forEach(function(c) { c.classList.remove('selected'); });
  document.getElementById('patient-name').value = '';
  document.getElementById('patient-age').value = '';
  document.getElementById('patient-notes').value = '';
  state.selectedHospital = null;
  state.selectedCondition = null;
  checkDispatchReady();

  // Reset other panels
  document.getElementById('police-idle').classList.remove('hidden');
  document.getElementById('police-active').classList.add('hidden');
  document.getElementById('police-status-text').textContent = 'Monitoring zone';
  document.getElementById('hosp-idle').classList.remove('hidden');
  document.getElementById('hosp-active').classList.add('hidden');
  document.getElementById('h-incoming-count').textContent = '0';
  document.getElementById('hosp-log').innerHTML = '';
}

function renderDriverCheckpoints() {
  var list = document.getElementById('driver-checkpoints');
  list.innerHTML = '';
  state.checkpoints.forEach(function(cp) {
    var item = document.createElement('div');
    item.className = 'checkpoint-item';
    item.id = 'driver-cp-' + cp.id;

    var circleClass = cp.status === 'done' ? 'cp-done' : cp.status === 'active' ? 'cp-active' : 'cp-pending';
    var circleContent = cp.status === 'done' ? '✓' : cp.id;

    item.innerHTML =
      '<div class="cp-circle ' + circleClass + '">' + circleContent + '</div>' +
      '<div class="cp-info">' +
        '<span class="cp-name">' + cp.name + '</span>' +
        '<span class="cp-sub">' + cp.zone + ' · ETA ' + cp.eta + ' min</span>' +
      '</div>' +
      '<span class="cp-action ' + (cp.status === 'done' ? 'cp-action-done' : cp.status === 'active' ? 'cp-action-needed' : 'cp-action-standby') + '">' +
        (cp.status === 'done' ? 'Cleared' : cp.status === 'active' ? 'Active' : 'Standby') +
      '</span>';

    list.appendChild(item);
  });
}

// ===================== POLICE =====================
function syncPolicePanel() {
  if (!state.selectedHospital) return;
  document.getElementById('police-idle').classList.add('hidden');
  document.getElementById('police-active').classList.remove('hidden');
  document.getElementById('police-status-text').textContent = 'ALERT — ambulance en route';
  document.getElementById('police-alert-dest').textContent = 'En route to ' + state.selectedHospital.name;
  document.getElementById('police-condition').textContent = state.selectedCondition;
  document.getElementById('police-hospital').textContent = state.selectedHospital.name;
  document.getElementById('police-priority-badge').textContent = state.selectedCondition === 'Critical' ? 'P1' : state.selectedCondition === 'Serious' ? 'P2' : 'P3';
  document.getElementById('police-eta').textContent = state.selectedHospital.time + ' min';
  renderPoliceCheckpoints();
}

function renderPoliceCheckpoints() {
  var list = document.getElementById('police-checkpoints');
  list.innerHTML = '';
  state.checkpoints.forEach(function(cp) {
    var item = document.createElement('div');
    item.className = 'checkpoint-item';
    item.id = 'police-cp-' + cp.id;

    var isActive = cp.status === 'active';
    var isDone = cp.status === 'done';
    var circleClass = isDone ? 'cp-done' : isActive ? 'cp-active' : 'cp-pending';
    var circleContent = isDone ? '✓' : cp.id;

    var actionHtml = isDone
      ? '<span class="cp-action cp-action-done">Cleared</span>'
      : isActive
      ? '<button class="cp-action cp-action-needed" onclick="clearCheckpoint(' + cp.id + ')">Clear now</button>'
      : '<span class="cp-action cp-action-standby">Standby</span>';

    item.innerHTML =
      '<div class="cp-circle ' + circleClass + '">' + circleContent + '</div>' +
      '<div class="cp-info">' +
        '<span class="cp-name">' + cp.name + '</span>' +
        '<span class="cp-sub">' + cp.zone + ' · ETA ' + cp.eta + ' min</span>' +
      '</div>' +
      actionHtml;

    list.appendChild(item);
  });
}

function clearCheckpoint(id) {
  var cp = state.checkpoints.find(function(c) { return c.id === id; });
  if (!cp) return;
  cp.status = 'done';
  renderDriverCheckpoints();
  renderPoliceCheckpoints();
  addLog('driver-log', 'Checkpoint ' + id + ': ' + cp.name + ' cleared by police', 'success');
  addLog('hosp-log', 'Traffic cleared at ' + cp.name, 'success');
}

// ===================== HOSPITAL =====================
function syncHospitalPanel() {
  if (!state.selectedHospital) return;
  document.getElementById('hosp-idle').classList.add('hidden');
  document.getElementById('hosp-active').classList.remove('hidden');
  document.getElementById('h-incoming-count').textContent = '1';
  document.getElementById('hosp-condition').textContent = state.selectedCondition;
  document.getElementById('hosp-eta').textContent = state.selectedHospital.time + ' min';
  document.getElementById('hosp-patient').textContent = state.patientName + (state.patientAge !== '--' ? ', ' + state.patientAge + ' yrs' : '');
  renderChecklist();
  addLog('hosp-log', 'Ambulance dispatched — prepare ER bay 2', 'danger');
}

function renderChecklist() {
  var items = checklistItems[state.selectedCondition] || checklistItems['Stable'];
  var list = document.getElementById('hosp-checklist');
  list.innerHTML = '';
  items.forEach(function(label) {
    var div = document.createElement('div');
    div.className = 'checklist-item';
    div.onclick = function() { toggleCheckItem(div); };
    div.innerHTML =
      '<div class="check-box"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" style="display:none"><polyline points="20 6 9 17 4 12"/></svg></div>' +
      '<span class="check-label">' + label + '</span>';
    list.appendChild(div);
  });
}

function toggleCheckItem(el) {
  el.classList.toggle('checked');
  var svg = el.querySelector('svg');
  svg.style.display = el.classList.contains('checked') ? 'block' : 'none';
}

// ===================== MAP =====================
function drawMap(canvasId) {
  var canvas = document.getElementById(canvasId);
  if (!canvas) return;
  var ctx = canvas.getContext('2d');
  var w = canvas.width, h = canvas.height;

  ctx.clearRect(0, 0, w, h);

  // Background
  ctx.fillStyle = '#E8EDF2';
  ctx.fillRect(0, 0, w, h);

  // Grid roads
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 8;
  for (var i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(0, h * (i / 4));
    ctx.lineTo(w, h * (i / 4));
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * (i / 4), 0);
    ctx.lineTo(w * (i / 4), h);
    ctx.stroke();
  }

  // Route line
  ctx.strokeStyle = '#FF3B30';
  ctx.lineWidth = 3;
  ctx.setLineDash([8, 4]);
  ctx.beginPath();
  ctx.moveTo(w * 0.1, h * 0.82);
  ctx.lineTo(w * 0.35, h * 0.55);
  ctx.lineTo(w * 0.6, h * 0.35);
  ctx.lineTo(w * 0.88, h * 0.12);
  ctx.stroke();
  ctx.setLineDash([]);

  // Checkpoint dots
  var checkPts = [
    [w * 0.35, h * 0.55],
    [w * 0.52, h * 0.44],
    [w * 0.68, h * 0.28],
    [w * 0.78, h * 0.2],
  ];

  checkPts.forEach(function(pt, i) {
    var cp = state.checkpoints[i];
    ctx.beginPath();
    ctx.arc(pt[0], pt[1], 6, 0, Math.PI * 2);
    ctx.fillStyle = cp && cp.status === 'done' ? '#34C759' : cp && cp.status === 'active' ? '#FF9500' : '#fff';
    ctx.strokeStyle = cp && cp.status === 'done' ? '#0F6E56' : cp && cp.status === 'active' ? '#CC7700' : '#888';
    ctx.lineWidth = 2;
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#444';
    ctx.font = 'bold 9px DM Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(i + 1, pt[0], pt[1] + 3.5);
  });
}

// ===================== SIMULATION =====================
function startSim() {
  state.progress = 0;
  if (state.simTimer) clearInterval(state.simTimer);

  state.simTimer = setInterval(function() {
    if (!state.tripActive) { clearInterval(state.simTimer); return; }

    state.progress = Math.min(state.progress + 0.7, 100);
    var p = state.progress;

    // Update ETA and distance
    var timeLeft = Math.max(0, Math.round(state.selectedHospital.time * (1 - p / 100)));
    var distLeft = Math.max(0, state.selectedHospital.dist * (1 - p / 100));
    var speed = p > 5 && p < 98 ? Math.round(45 + Math.random() * 25) : 0;

    document.getElementById('trip-eta').textContent = timeLeft;
    document.getElementById('trip-dist').textContent = distLeft.toFixed(1);
    document.getElementById('trip-speed').textContent = speed;

    if (document.getElementById('hosp-eta')) {
      document.getElementById('hosp-eta').textContent = timeLeft + ' min';
    }
    if (document.getElementById('police-eta')) {
      document.getElementById('police-eta').textContent = timeLeft + ' min';
    }

    // Move ambulance marker
    var ax = 12 + p * 0.76;
    var ay = 82 - p * 0.72;
    ax = Math.min(ax, 88); ay = Math.max(ay, 10);
    moveMarker('ambu-marker', ax, ay);
    moveMarker('police-ambu-marker', ax, ay);
    moveMarker('hosp-ambu-marker', ax, ay);

    // Checkpoint activation
    var cpThresholds = [25, 50, 72, 90];
    cpThresholds.forEach(function(thresh, i) {
      var cp = state.checkpoints[i];
      if (p >= thresh && cp.status === 'pending') {
        cp.status = 'active';
        renderDriverCheckpoints();
        renderPoliceCheckpoints();
        addLog('driver-log', 'Approaching checkpoint ' + (i+1) + ': ' + cp.name, 'warning');
        drawMap('map-canvas');
        drawMap('police-map-canvas');
        drawMap('hosp-map-canvas');
      }
    });

    // Fired sim events
    simEvents.forEach(function(ev) {
      if (p >= ev.pct && firedEvents.indexOf(ev.pct) === -1) {
        firedEvents.push(ev.pct);
        addLog('driver-log', ev.msg, ev.type);
        addLog('hosp-log', ev.msg, ev.type);
      }
    });

    // End of trip
    if (p >= 100) {
      clearInterval(state.simTimer);
      state.checkpoints.forEach(function(cp) { cp.status = 'done'; });
      renderDriverCheckpoints();
      renderPoliceCheckpoints();
      drawMap('map-canvas');
      drawMap('police-map-canvas');
      drawMap('hosp-map-canvas');
      document.getElementById('driver-status-text').textContent = 'Trip complete';
      document.getElementById('trip-speed').textContent = '0';
    }
  }, 100);
}

function moveMarker(id, xPct, yPct) {
  var el = document.getElementById(id);
  if (el) {
    el.style.left = xPct + '%';
    el.style.top = yPct + '%';
  }
}

// ===================== LOG =====================
function addLog(containerId, msg, type) {
  var container = document.getElementById(containerId);
  if (!container) return;
  var now = new Date();
  var time = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0') + ':' + String(now.getSeconds()).padStart(2, '0');
  var div = document.createElement('div');
  div.className = 'log-item log-' + type;
  div.innerHTML =
    '<div class="log-dot"></div>' +
    '<div style="flex:1">' +
      '<div class="log-text">' + msg + '</div>' +
      '<div class="log-time">' + time + '</div>' +
    '</div>';
  container.insertBefore(div, container.firstChild);
  // Keep only last 12 entries
  while (container.children.length > 12) {
    container.removeChild(container.lastChild);
  }
}
