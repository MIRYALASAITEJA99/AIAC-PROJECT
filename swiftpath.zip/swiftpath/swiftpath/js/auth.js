// ===================== STORAGE HELPERS =====================
function getUsers() {
  try {
    return JSON.parse(localStorage.getItem('swiftpath_users') || '[]');
  } catch(e) { return []; }
}

function saveUsers(users) {
  localStorage.setItem('swiftpath_users', JSON.stringify(users));
}

function setSession(user) {
  localStorage.setItem('swiftpath_session', JSON.stringify({
    id: user.id,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    phone: user.phone,
    role: user.role,
    extra: user.extra || '',
    loggedIn: true,
    loginTime: new Date().toISOString()
  }));
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem('swiftpath_session') || 'null');
  } catch(e) { return null; }
}

function clearSession() {
  localStorage.removeItem('swiftpath_session');
}

// Seed demo accounts on first load
(function seedDemoAccounts() {
  var users = getUsers();
  var demoEmails = ['driver@swiftpath.in', 'police@swiftpath.in', 'hospital@swiftpath.in'];
  var hasAll = demoEmails.every(function(e) {
    return users.some(function(u) { return u.email === e; });
  });
  if (hasAll) return;

  var demos = [
    { id: 'demo-1', firstName: 'Arjun', lastName: 'Rajan', email: 'driver@swiftpath.in', password: 'driver123', phone: '+91 98765 00001', role: 'driver', extra: 'TN01AB1234' },
    { id: 'demo-2', firstName: 'Sgt. Murugan', lastName: 'K', email: 'police@swiftpath.in', password: 'police123', phone: '+91 98765 00002', role: 'police', extra: 'Zone 2 — Anna Salai' },
    { id: 'demo-3', firstName: 'Dr. Priya', lastName: 'Nair', email: 'hospital@swiftpath.in', password: 'hospital123', phone: '+91 98765 00003', role: 'hospital', extra: 'Apollo Hospitals, Greams Rd' },
  ];

  demos.forEach(function(d) {
    if (!users.some(function(u) { return u.email === d.email; })) {
      users.push(d);
    }
  });
  saveUsers(users);
})();

// ===================== LOGIN =====================
function handleLogin(e) {
  e.preventDefault();
  var email = document.getElementById('login-email').value.trim().toLowerCase();
  var password = document.getElementById('login-password').value;
  var role = document.querySelector('input[name="role"]:checked').value;

  var btn = document.getElementById('login-btn');
  btn.classList.add('loading');
  btn.querySelector('.btn-text').textContent = 'Signing in...';

  setTimeout(function() {
    var users = getUsers();
    var user = users.find(function(u) {
      return u.email.toLowerCase() === email && u.password === password && u.role === role;
    });

    if (!user) {
      showError('login-error', 'login-error-msg', 'Incorrect email, password, or role. Try a demo account below.');
      btn.classList.remove('loading');
      btn.querySelector('.btn-text').textContent = 'Sign in';
      return;
    }

    setSession(user);

    // Redirect to main app
    var base = window.location.pathname.replace('/pages/login.html', '');
    window.location.href = base + '/index.html';
  }, 800);
}

function fillDemo(email, password, role) {
  document.getElementById('login-email').value = email;
  document.getElementById('login-password').value = password;
  var radios = document.querySelectorAll('input[name="role"]');
  radios.forEach(function(r) { r.checked = (r.value === role); });
}

// ===================== REGISTER =====================
function handleRegister(e) {
  e.preventDefault();

  var firstName = document.getElementById('reg-firstname').value.trim();
  var lastName  = document.getElementById('reg-lastname').value.trim();
  var email     = document.getElementById('reg-email').value.trim().toLowerCase();
  var phone     = document.getElementById('reg-phone').value.trim();
  var role      = document.querySelector('input[name="reg-role"]:checked').value;
  var extra     = document.getElementById('reg-extra').value.trim();
  var password  = document.getElementById('reg-password').value;
  var confirm   = document.getElementById('reg-confirm').value;
  var terms     = document.getElementById('reg-terms').checked;

  if (!terms) {
    showError('reg-error', 'reg-error-msg', 'Please accept the Terms of Service to continue.');
    return;
  }

  if (password.length < 8) {
    showError('reg-error', 'reg-error-msg', 'Password must be at least 8 characters long.');
    return;
  }

  if (password !== confirm) {
    showError('reg-error', 'reg-error-msg', 'Passwords do not match. Please try again.');
    return;
  }

  var users = getUsers();
  if (users.some(function(u) { return u.email.toLowerCase() === email; })) {
    showError('reg-error', 'reg-error-msg', 'An account with this email already exists. Try signing in.');
    return;
  }

  var btn = document.getElementById('reg-btn');
  btn.classList.add('loading');
  btn.querySelector('.btn-text').textContent = 'Creating account...';

  setTimeout(function() {
    var newUser = {
      id: 'user-' + Date.now(),
      firstName: firstName,
      lastName: lastName,
      email: email,
      phone: phone,
      role: role,
      extra: extra,
      password: password,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    document.getElementById('reg-error').classList.add('hidden');
    document.getElementById('reg-success').classList.remove('hidden');

    btn.querySelector('.btn-text').textContent = 'Account created!';

    setTimeout(function() {
      var base = window.location.pathname.replace('/pages/register.html', '');
      window.location.href = base + '/pages/login.html';
    }, 1800);
  }, 900);
}

// ===================== ROLE EXTRA FIELD =====================
(function initRoleExtra() {
  var radios = document.querySelectorAll('input[name="reg-role"]');
  if (!radios.length) return;

  var labels = {
    driver: { label: 'Ambulance vehicle number', placeholder: 'TN01AB1234' },
    police: { label: 'Zone / Station', placeholder: 'Zone 2 — Anna Salai' },
    hospital: { label: 'Hospital & department', placeholder: 'Apollo Hospitals, ER Dept' }
  };

  function updateExtra(role) {
    var lbl = document.getElementById('role-extra-label');
    var inp = document.getElementById('reg-extra');
    if (lbl && inp && labels[role]) {
      lbl.textContent = labels[role].label;
      inp.placeholder = labels[role].placeholder;
    }
  }

  radios.forEach(function(r) {
    r.addEventListener('change', function() { updateExtra(this.value); });
  });

  var checked = document.querySelector('input[name="reg-role"]:checked');
  if (checked) updateExtra(checked.value);
})();

// ===================== PASSWORD STRENGTH =====================
function checkPasswordStrength(pw) {
  var fill = document.getElementById('strength-fill');
  var label = document.getElementById('strength-label');
  if (!fill || !label) return;

  var score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;

  var levels = [
    { w: '0%', bg: 'transparent', text: '' },
    { w: '25%', bg: '#FF3B30', text: 'Weak' },
    { w: '50%', bg: '#FF9500', text: 'Fair' },
    { w: '75%', bg: '#007AFF', text: 'Good' },
    { w: '100%', bg: '#34C759', text: 'Strong' },
  ];

  var lvl = levels[Math.min(score, 4)];
  fill.style.width = lvl.w;
  fill.style.background = lvl.bg;
  label.textContent = lvl.text;
  label.style.color = lvl.bg;
}

// ===================== TOGGLE PASSWORD =====================
function togglePassword(inputId, btn) {
  var input = document.getElementById(inputId);
  if (!input) return;
  var isText = input.type === 'text';
  input.type = isText ? 'password' : 'text';
  btn.style.opacity = isText ? '1' : '0.5';
}

// ===================== SHOW ERROR =====================
function showError(containerId, msgId, msg) {
  var container = document.getElementById(containerId);
  var msgEl = document.getElementById(msgId);
  if (container) container.classList.remove('hidden');
  if (msgEl) msgEl.textContent = msg;

  if (container) {
    container.style.animation = 'none';
    void container.offsetWidth;
    container.style.animation = 'shake 0.4s ease';
  }
}
